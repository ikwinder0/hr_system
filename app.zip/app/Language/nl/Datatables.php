<?php

// override core en language system validation or define your own en language validation message
return [
	'xin_dt_lengthMenu' => 'Toon _MENU_ items',
	'xin_dt_zeroRecords' => 'Geen records beschikbaar',
	'xin_dt_info' => 'Toont _START_ tot _END_ van _TOTAL_ records',
	'xin_dt_infoEmpty' => 'Geen records beschikbaar',
	'xin_dt_infoFiltered' => '(gefilterd uit _MAX_ totaal aantal records)',
	'xin_dt_search' => 'Zoeken',
	'dt_first' => 'Eerste',
	'dt_previous' => 'Vorige',
	'dt_next' => 'Volgende',
	'dt_last' => 'Laatste'
];