<?php

//Dashboard override core en language system validation or define your own en language validation message
return [
'xin_events_calendar'=>'事件日历',
'xin_event'=>'事件',
'xin_event_title'=>'事件标题',
'xin_hr_event_date'=>'事件日期',
'xin_hr_event_time'=>'事件时间',
'xin_event_color'=>'事件颜色',
'xin_hr_event_note'=>'事件注释',
'xin_edit_event'=>'编辑事件',
'xin_hr_meeting_title'=>'会议标题',
'xin_hr_meeting_date'=>'会议日期',
'xin_hr_meeting_time'=>'会议时间',
'xin_meeting_room'=>'会议室',
'xin_meeting_color'=>'颜色',
'xin_hr_meeting_note'=>'注释',
'xin_edit_meeting'=>'编辑会议',
'xin_conference_calendar'=>'会议日历',
'xin_conference'=>'会议',
];