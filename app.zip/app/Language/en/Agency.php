<?php

return [
	'create_agency' => 'Create Agency',
	'xin_create_new_agency' => 'Create New Agency',
	'xin_agency_name'       => 'Agency Name',
	'xin_country'           => 'Country',
	'xin_address'           => 'Address',
	'xin_phone_no'          => 'Phone No.',
	'xin_email_address' => 'Email Address',
	'xin_agency_website' => 'Agency Website',
	'xin_contact_person' => 'Contact Person',
	'xin_contact_person_phone' => 'Phone',
	'xin_attachments' => 'Attachment',
	'xin_logo'   => 'Agency Logo',
	'xin_register'   => 'Register',
	'xin_cr_and_tax_card' => 'CR & Tax Card',
	'xin_beneficiary_and_bank_account' => 'Beneficiary Name & Bank Account Details',
	'xin_bank_certificate' => 'Bank Certificate',
	'xin_bank_account_with_seal' => 'Bank Account Details with Seal and Signature on Company Letter Pad'
	];