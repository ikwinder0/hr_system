<?php

//Dashboard override core en language system validation or define your own en language validation message
return [
'xin_languages' => 'Lingue',
'xin_language' => 'Lingua',
'xin_flag' => 'Bandiera',
'xin_error_lang_name' => 'Il campo del nome della lingua è obbligatorio.',
'xin_error_lang_code' => 'Il campo del codice della lingua è obbligatorio.',
'xin_error_lang_flag' => 'Il campo della bandiera della lingua è obbligatorio.',
'xin_success_lang_added' => 'Lingua aggiunta.',
'xin_success_lang_updated' => 'Lingua aggiornata.',
'xin_success_lang_deleted' => 'Lingua eliminata.',
'xin_success_lang_activated' => 'Lingua attivata.',
'xin_success_lang_deactivated' => 'Lingua disattivata.',
];