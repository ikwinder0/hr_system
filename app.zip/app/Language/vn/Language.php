<?php

//Dashboard override core en language system validation or define your own en language validation message
return [
'xin_languages' => 'Ngôn ngữ',
'xin_language' => 'Ngôn ngữ',
'xin_flag' => 'Gắn cờ',
'xin_error_lang_name' => 'Trường tên ngôn ngữ là bắt buộc.',
'xin_error_lang_code' => 'Trường mã ngôn ngữ là bắt buộc.',
'xin_error_lang_flag' => 'Trường cờ ngôn ngữ là bắt buộc.',
'xin_success_lang_added' => 'Đã thêm ngôn ngữ.',
'xin_success_lang_updated' => 'Đã cập nhật ngôn ngữ.',
'xin_success_lang_deleted' => 'Đã xóa ngôn ngữ.',
'xin_success_lang_actiised' => 'Đã kích hoạt ngôn ngữ.',
'xin_success_lang_deactiised' => 'Ngôn ngữ không được kích hoạt.',
];