<?php

// override core en language system validation or define your own en language validation message
return [
'xin_dt_lengthMenu' => '_MENU_ girişlerini göster',
'xin_dt_zeroRecords' => 'Kullanılabilir kayıt yok',
'xin_dt_info' => '_TOTAL_ kayıttan _START_ - _END_ arasındakiler gösteriliyor',
'xin_dt_infoEmpty' => 'Kullanılabilir kayıt yok',
'xin_dt_infoFiltered' => '(_MAX_ toplam kayıttan filtrelenmiştir)',
'xin_dt_search' => 'Ara',
'dt_first' => 'İlk',
'dt_previous' => 'Önceki',
'dt_next' => 'Sonraki',
'dt_last' => 'Son'
];